tb = getHTMLFormDescription("http://www.genome.ucsc.edu/cgi-bin/hgTables")
