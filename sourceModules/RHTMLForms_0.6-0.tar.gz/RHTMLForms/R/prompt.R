#
# Generate help for the function that we have created.
#
#

prompt.HTMLFormGeneratedFunction =
function(f, name)
{
  f
}

